// item_reader_1_26_50.h
// Item reading interface for Minecraft 1.26.50
#pragma once

#include <string>
#include <vector>
#include <utility>

struct ItemInfo {
    std::string itemId;
    int durability;
    int maxDurability;
    int count;
    std::vector<std::pair<std::string, int>> enchantments;
    bool isEmpty;
    
    bool hasDurability() const { return maxDurability > 0; }
    bool hasEnchantments() const { return !enchantments.empty(); }
};

void initializeItemReader(uintptr_t baseAddress);
void* getPlayerInventory(void* player);
void* getItemInSlot(void* inventory, int slot);
bool isItemStackEmpty(void* itemStack);
ItemInfo readItemInfo(void* itemStack);
void testItemReader(void* player);
