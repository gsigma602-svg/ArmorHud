// brarchive_loader.h
// Minecraft Bedrock .brarchive file parser
// Compatible with format version 1 (introduced in 1.21.40, used in 1.26.50)
#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <cstring>

#pragma pack(push, 1)
struct BrArchiveHeader {
    uint64_t magic;        // 0x7D2725B1A0527026
    uint32_t numEntries;
    uint32_t version;      // Always 1
};

struct BrFileEntry {
    uint8_t nameLength;
    char name[247];
    uint32_t dataOffset;
    uint32_t dataSize;
};
#pragma pack(pop)

class BrArchiveLoader {
public:
    struct Entry {
        std::string name;
        std::vector<uint8_t> data;
        uint32_t offset;
        uint32_t size;
    };

    // Load from file on disk
    bool loadFromFile(const std::string& path);
    
    // Load from memory buffer
    bool loadFromMemory(const uint8_t* data, size_t size);
    
    // Get entry by exact filename
    const Entry* getEntry(const std::string& name) const;
    
    // Check if entry exists
    bool hasEntry(const std::string& name) const;
    
    // Get texture data by Minecraft-style path
    // Handles both "textures/ui/hotbar_5" and "ui/hotbar_5.png"
    const std::vector<uint8_t>* getTextureData(const std::string& texturePath) const;
    
    // Get all entries
    const std::unordered_map<std::string, Entry>& getAllEntries() const { return m_entries; }
    
    // Check if archive is loaded
    bool isLoaded() const { return m_loaded; }
    
    // Get number of entries
    size_t getEntryCount() const { return m_entries.size(); }
    
    // Clear all data
    void clear();

private:
    std::unordered_map<std::string, Entry> m_entries;
    bool m_loaded = false;
};
