// config_manager.h
// Configuration management for ArmorHud
#pragma once

#include <string>

struct Config {
    bool enable = true;
    bool editmode = false;
    
    // Equipment visibility
    bool enableHelmet = true;
    bool enableChestplate = true;
    bool enableLeggings = true;
    bool enableBoots = true;
    bool enableMainhand = true;
    bool enableOffhand = true;
    
    // Position
    float anchorX = 10.0f;
    float anchorY = 100.0f;
    
    // Offsets
    float iconOffsetX = 0.0f;
    float iconOffsetY = 0.0f;
    float textOffsetX = 20.0f;
    float textOffsetY = 4.0f;
    
    // Display options
    bool useDurabilityBar = true;
    bool useDurabilityText = false;
    bool showEnchantments = true;
    bool showBackground = true;
    bool textShadow = true;
    
    // Limits
    int maxEnchantmentsToShow = 5;
    bool useShortEnchantmentNames = false;
};

extern Config g_config;

void loadConfig();
void saveConfig();
