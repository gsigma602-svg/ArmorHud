// texture_manager_1_26_50.h
// Complete texture management system for Minecraft 1.26.50
// FIX #1: brarchive texture loading integration
#pragma once

#include "brarchive_loader.h"
#include <string>
#include <unordered_map>
#include <GLES3/gl3.h>

class TextureManager {
public:
    struct TextureInfo {
        GLuint id;
        int width;
        int height;
        bool loaded;
    };

private:
    BrArchiveLoader m_brarchiveLoader;
    std::unordered_map<std::string, TextureInfo> m_textureCache;
    bool m_useBrarchive = false;
    std::string m_resourcePath;
    
public:
    TextureManager() = default;
    ~TextureManager();
    
    // Initialize texture manager
    // resourcePath = path to Minecraft's resource pack (e.g., /data/app/.../assets/resource_packs/vanilla)
    bool initialize(const std::string& resourcePath);
    
    // Get or load a texture by Minecraft-style path
    // Examples: "textures/ui/hotbar_5", "textures/entity/player/steve"
    GLuint getTexture(const std::string& path);
    
    // Get texture info (includes dimensions)
    const TextureInfo* getTextureInfo(const std::string& path);
    
    // Check if texture is loaded
    bool hasTexture(const std::string& path) const;
    
    // Bind texture for rendering
    void bindTexture(const std::string& path, GLuint textureUnit = 0);
    
    // Clear all loaded textures
    void clear();
    
    // Get resource path
    const std::string& getResourcePath() const { return m_resourcePath; }
    
    // Check if using brarchive
    bool isUsingBrarchive() const { return m_useBrarchive; }
    
private:
    // Try to load texture from brarchive
    GLuint loadFromBrarchive(const std::string& path, TextureInfo& info);
    
    // Try to load texture from file
    GLuint loadFromFile(const std::string& path, TextureInfo& info);
    
    // Load texture from PNG data in memory
    GLuint loadPNGFromMemory(const uint8_t* data, size_t size, TextureInfo& info);
    
    // Convert Minecraft texture path to file path
    std::string texturePathToFilePath(const std::string& texturePath) const;
};

// Global instance
TextureManager& getTextureManager();
