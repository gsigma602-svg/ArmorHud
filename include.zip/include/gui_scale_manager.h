// gui_scale_manager.h
// Simple GUI scale manager for Minecraft 1.26.50
// FIX #8: GUI scale handling
#pragma once

#include <algorithm>

class GUIScaleManager {
private:
    float m_currentScale = 1.0f;
    bool m_autoDetect = true;
    
public:
    // Get current GUI scale factor
    float getScale() const {
        return m_currentScale;
    }
    
    // Set GUI scale manually
    void setScale(float scale) {
        m_currentScale = std::max(0.5f, std::min(4.0f, scale));
    }
    
    // Enable/disable auto-detection from Minecraft settings
    void setAutoDetect(bool enable) {
        m_autoDetect = enable;
    }
    
    bool isAutoDetect() const {
        return m_autoDetect;
    }
    
    // Scale a pixel value
    float scalePixel(float pixels) const {
        return pixels * m_currentScale;
    }
    
    // Unscale a pixel value (for config storage)
    float unscalePixel(float scaledPixels) const {
        return scaledPixels / m_currentScale;
    }
    
    // Update scale from Minecraft's GUI scale setting
    // Call this when settings change or on initialization
    void updateFromMinecraft() {
        if (!m_autoDetect) {
            return;
        }
        
        // Read GUI scale from Minecraft options
        // This requires hooking into Minecraft's settings system
        int mcScale = readMinecraftGUIScale();
        
        // Convert Minecraft's GUI scale to float factor
        // Minecraft scale values: 0=Auto, 1=Small, 2=Normal, 3=Large, 4=Extra Large
        float scaleFactors[] = { 1.0f, 0.75f, 1.0f, 1.5f, 2.0f };
        
        int index = std::max(0, std::min(4, mcScale));
        m_currentScale = scaleFactors[index];
    }
    
private:
    // Read GUI scale from Minecraft (needs to be implemented with actual hooks)
    int readMinecraftGUIScale() {
        // TODO: Hook into Minecraft's Options class to read GUI scale
        // This is a placeholder - actual implementation requires:
        // 1. Finding Options::guiScale offset in libminecraftpe.so
        // 2. Reading the value from memory
        
        // For now, return default
        return 2; // Normal scale
    }
};

// Global instance
inline GUIScaleManager& getGUIScaleManager() {
    static GUIScaleManager instance;
    return instance;
}

// Convenience functions
inline float scalePixel(float pixels) {
    return getGUIScaleManager().scalePixel(pixels);
}

inline float unscalePixel(float scaledPixels) {
    return getGUIScaleManager().unscalePixel(scaledPixels);
}
