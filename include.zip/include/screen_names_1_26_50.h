// screen_names_1_26_50.h
// Updated screen names for Minecraft 1.26.50
// FIX #4: Screen detection
#pragma once

#include <string>
#include <vector>

namespace ScreenNames {

// Screens where HUD SHOULD be visible (in-game screens)
const std::vector<std::string> VISIBLE_SCREENS = {
    "start_screen",           // Main menu (for config access)
    "play_screen",            // World selection (NEW in 1.26.50)
    "world_screen",           // In-game world view (NEW in 1.26.50)
    "hud_screen",             // In-game HUD overlay
    "in_game_play_screen",    // Alternative name for in-game
    "chat_screen",            // Chat overlay (still in-game)
    "debug_screen",           // F3 debug screen
    "toast_screen",           // Toast notifications
};

// Screens where HUD should be HIDDEN (menu/inventory screens)
const std::vector<std::string> HIDDEN_SCREENS = {
    // Inventory & Crafting
    "inventory_screen",       // Player inventory
    "crafting_screen",        // Crafting table
    "recipe_book_screen",     // Recipe book
    
    // Containers
    "chest_screen",           // Chest/container
    "large_chest_screen",     // Large chest
    "shulker_box_screen",     // Shulker box
    "barrel_screen",          // Barrel
    "hopper_screen",          // Hopper
    "dispenser_screen",       // Dispenser
    "dropper_screen",         // Dropper
    
    // Utility Blocks
    "furnace_screen",         // Furnace
    "blast_furnace_screen",   // Blast furnace
    "smoker_screen",          // Smoker
    "enchanting_screen",      // Enchanting table
    "anvil_screen",           // Anvil
    "brewing_screen",         // Brewing stand
    "beacon_screen",          // Beacon
    "grindstone_screen",      // Grindstone
    "smithing_screen",        // Smithing table
    "loom_screen",            // Loom
    "cartography_screen",     // Cartography table
    "stonecutter_screen",     // Stonecutter
    
    // Trading
    "villager_screen",        // Villager trading
    "wandering_trader_screen", // Wandering trader
    
    // Interaction
    "book_screen",            // Book & quill / written book
    "sign_screen",            // Sign editing
    "command_block_screen",   // Command block
    "structure_block_screen", // Structure block
    "jigsaw_block_screen",    // Jigsaw block
    
    // Menus
    "pause_screen",           // Pause menu
    "settings_screen",        // Settings
    "video_settings_screen",  // Video settings
    "controls_screen",        // Controls
    "language_screen",        // Language selection
    "accessibility_screen",   // Accessibility settings
    
    // Online Features (NEW in 1.26.50)
    "marketplace_screen",     // Marketplace
    "marketplace_pass_screen", // Marketplace Pass
    "realms_screen",          // Realms menu
    "realms_world_screen",    // Realms world settings
    "social_screen",          // Friends/social (NEW in 1.26.50)
    "friends_screen",         // Friends list
    "invite_screen",          // Invite friends
    "feedback_screen",        // Feedback
    
    // Other
    "death_screen",           // Death screen
    "credits_screen",         // Credits
    "how_to_play_screen",     // How to play
    "patch_notes_screen",     // Patch notes
};

// Check if HUD should be visible on current screen
inline bool shouldShowHUD(const std::string& currentScreen) {
    if (currentScreen.empty()) {
        return false;
    }
    
    // Check if screen is explicitly in visible list
    for (const auto& screen : VISIBLE_SCREENS) {
        if (currentScreen == screen) {
            return true;
        }
        // Also check if screen name contains the pattern
        if (currentScreen.find(screen) != std::string::npos) {
            return true;
        }
    }
    
    // Check if screen is explicitly in hidden list
    for (const auto& screen : HIDDEN_SCREENS) {
        if (currentScreen == screen) {
            return false;
        }
        if (currentScreen.find(screen) != std::string::npos) {
            return false;
        }
    }
    
    // Default: Show HUD for unknown screens
    // This is safer than hiding it
    return true;
}

// Check if we're in edit mode screen
inline bool isEditModeScreen(const std::string& currentScreen) {
    return currentScreen == "start_screen" || 
           currentScreen == "debug_screen";
}

// Get screen type for logging
inline std::string getScreenType(const std::string& currentScreen) {
    for (const auto& screen : VISIBLE_SCREENS) {
        if (currentScreen.find(screen) != std::string::npos) {
            return "visible";
        }
    }
    for (const auto& screen : HIDDEN_SCREENS) {
        if (currentScreen.find(screen) != std::string::npos) {
            return "hidden";
        }
    }
    return "unknown";
}

} // namespace ScreenNames
