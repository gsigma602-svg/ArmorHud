// render_hook_manager.h
// Rendering hook system with Vibrant Visuals support
// FIX #5: Rendering pipeline hooks for Minecraft 1.26.50
#pragma once

#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <functional>

class RenderHookManager {
public:
    // Callback for HUD rendering (set by mod)
    using RenderCallback = std::function<void()>;
    
private:
    // State tracking
    GLuint m_currentFramebuffer = 0;
    int m_swapCount = 0;
    bool m_isFinalPass = false;
    bool m_vibrantVisualsEnabled = false;
    
    // Callbacks
    RenderCallback m_hudRenderCallback;
    
    // Original function pointers (saved before hooking)
    void* m_originalEglSwapBuffers = nullptr;
    void* m_originalGlBindFramebuffer = nullptr;
    void* m_originalGlBlitFramebuffer = nullptr;
    
    // GL state for restoration
    struct GLState {
        GLint viewport[4];
        GLboolean blendEnabled;
        GLboolean depthEnabled;
        GLboolean cullEnabled;
        GLboolean scissorEnabled;
        GLint blendSrcRGB, blendDstRGB;
        GLint blendSrcAlpha, blendDstAlpha;
        GLint blendEquationRGB, blendEquationAlpha;
        GLuint currentProgram;
        GLuint currentVAO;
        GLuint currentTexture;
    };
    
public:
    RenderHookManager() = default;
    ~RenderHookManager();
    
    // Initialize hooks (call once at startup)
    bool initialize();
    
    // Shutdown hooks (call on exit)
    void shutdown();
    
    // Set HUD render callback
    void setRenderCallback(RenderCallback callback);
    
    // Check if Vibrant Visuals is enabled
    bool isVibrantVisualsEnabled() const { return m_vibrantVisualsEnabled; }
    
    // Manually set Vibrant Visuals state (if auto-detection fails)
    void setVibrantVisualsEnabled(bool enabled);
    
    // Get current framebuffer
    GLuint getCurrentFramebuffer() const { return m_currentFramebuffer; }
    
    // Check if we're in the final render pass
    bool isFinalPass() const { return m_isFinalPass; }
    
private:
    // Hooked functions
    static EGLBoolean hookedEglSwapBuffers(EGLDisplay dpy, EGLSurface surf);
    static void hookedGlBindFramebuffer(GLenum target, GLuint framebuffer);
    static void hookedGlBlitFramebuffer(GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1,
                                        GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1,
                                        GLbitfield mask, GLenum filter);
    
    // Render HUD (called from hooked eglSwapBuffers)
    void renderHUD();
    
    // Save and restore GL state
    GLState saveGLState();
    void restoreGLState(const GLState& state);
    
    // Detect if this is the final swap
    bool detectFinalSwap();
    
    // Detect Vibrant Visuals
    void detectVibrantVisuals();
    
    // Static instance for hooks
    static RenderHookManager* s_instance;
};

// Global instance
RenderHookManager& getRenderHookManager();
