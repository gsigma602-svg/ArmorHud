// enchantment_names_1_26_50.h
// Updated enchantment ID to display name mapping for Minecraft 1.26.50
// FIX #3: Enchantment data format (string IDs instead of numeric)
#pragma once

#include <string>
#include <unordered_map>

namespace EnchantmentNames {

// Complete mapping of enchantment IDs to display names
// Updated for Minecraft 1.26.50 (includes all enchantments up to this version)
const std::unordered_map<std::string, std::string> ENCHANTMENT_DISPLAY_NAMES = {
    // ===== ARMOR ENCHANTMENTS =====
    // Protection
    {"minecraft:protection", "Protection"},
    {"minecraft:fire_protection", "Fire Protection"},
    {"minecraft:blast_protection", "Blast Protection"},
    {"minecraft:projectile_protection", "Projectile Protection"},
    
    // Helmet-specific
    {"minecraft:respiration", "Respiration"},
    {"minecraft:aqua_affinity", "Aqua Affinity"},
    
    // Boots-specific
    {"minecraft:feather_falling", "Feather Falling"},
    {"minecraft:depth_strider", "Depth Strider"},
    {"minecraft:frost_walker", "Frost Walker"},
    {"minecraft:soul_speed", "Soul Speed"},
    {"minecraft:swift_sneak", "Swift Sneak"},
    
    // Armor universal
    {"minecraft:thorns", "Thorns"},
    
    // ===== WEAPON ENCHANTMENTS =====
    // Sword
    {"minecraft:sharpness", "Sharpness"},
    {"minecraft:smite", "Smite"},
    {"minecraft:bane_of_arthropods", "Bane of Arthropods"},
    {"minecraft:knockback", "Knockback"},
    {"minecraft:fire_aspect", "Fire Aspect"},
    {"minecraft:looting", "Looting"},
    {"minecraft:sweeping_edge", "Sweeping Edge"},
    
    // Mace (NEW in recent versions)
    {"minecraft:density", "Density"},
    {"minecraft:breach", "Breach"},
    {"minecraft:wind_burst", "Wind Burst"},
    
    // ===== TOOL ENCHANTMENTS =====
    // Mining tools
    {"minecraft:efficiency", "Efficiency"},
    {"minecraft:silk_touch", "Silk Touch"},
    {"minecraft:fortune", "Fortune"},
    
    // ===== BOW ENCHANTMENTS =====
    {"minecraft:power", "Power"},
    {"minecraft:punch", "Punch"},
    {"minecraft:flame", "Flame"},
    {"minecraft:infinity", "Infinity"},
    
    // ===== CROSSBOW ENCHANTMENTS =====
    {"minecraft:multishot", "Multishot"},
    {"minecraft:piercing", "Piercing"},
    {"minecraft:quick_charge", "Quick Charge"},
    
    // ===== TRIDENT ENCHANTMENTS =====
    {"minecraft:loyalty", "Loyalty"},
    {"minecraft:impaling", "Impaling"},
    {"minecraft:riptide", "Riptide"},
    {"minecraft:channeling", "Channeling"},
    
    // ===== FISHING ROD ENCHANTMENTS =====
    {"minecraft:luck_of_the_sea", "Luck of the Sea"},
    {"minecraft:lure", "Lure"},
    
    // ===== UNIVERSAL ENCHANTMENTS =====
    {"minecraft:unbreaking", "Unbreaking"},
    {"minecraft:mending", "Mending"},
    
    // ===== CURSE ENCHANTMENTS =====
    {"minecraft:binding_curse", "Curse of Binding"},
    {"minecraft:vanishing_curse", "Curse of Vanishing"},
    
    // ===== ALTERNATIVE/LEGACY IDs =====
    // Some versions may use these alternative formats
    {"protection", "Protection"},
    {"fire_protection", "Fire Protection"},
    {"feather_falling", "Feather Falling"},
    {"blast_protection", "Blast Protection"},
    {"projectile_protection", "Projectile Protection"},
    {"respiration", "Respiration"},
    {"aqua_affinity", "Aqua Affinity"},
    {"thorns", "Thorns"},
    {"depth_strider", "Depth Strider"},
    {"frost_walker", "Frost Walker"},
    {"binding_curse", "Curse of Binding"},
    {"soul_speed", "Soul Speed"},
    {"swift_sneak", "Swift Sneak"},
    {"sharpness", "Sharpness"},
    {"smite", "Smite"},
    {"bane_of_arthropods", "Bane of Arthropods"},
    {"knockback", "Knockback"},
    {"fire_aspect", "Fire Aspect"},
    {"looting", "Looting"},
    {"sweeping_edge", "Sweeping Edge"},
    {"efficiency", "Efficiency"},
    {"silk_touch", "Silk Touch"},
    {"unbreaking", "Unbreaking"},
    {"fortune", "Fortune"},
    {"power", "Power"},
    {"punch", "Punch"},
    {"flame", "Flame"},
    {"infinity", "Infinity"},
    {"luck_of_the_sea", "Luck of the Sea"},
    {"lure", "Lure"},
    {"loyalty", "Loyalty"},
    {"impaling", "Impaling"},
    {"riptide", "Riptide"},
    {"channeling", "Channeling"},
    {"multishot", "Multishot"},
    {"piercing", "Piercing"},
    {"quick_charge", "Quick Charge"},
    {"mending", "Mending"},
    {"vanishing_curse", "Curse of Vanishing"},
};

// Get display name for enchantment ID
inline std::string getDisplayName(const std::string& enchantmentId) {
    // Try exact match first
    auto it = ENCHANTMENT_DISPLAY_NAMES.find(enchantmentId);
    if (it != ENCHANTMENT_DISPLAY_NAMES.end()) {
        return it->second;
    }
    
    // Try lowercase version
    std::string lower = enchantmentId;
    for (char& c : lower) {
        c = std::tolower(c);
    }
    it = ENCHANTMENT_DISPLAY_NAMES.find(lower);
    if (it != ENCHANTMENT_DISPLAY_NAMES.end()) {
        return it->second;
    }
    
    // Fallback: Convert ID to readable format
    // "minecraft:sharpness" -> "Sharpness"
    std::string name = enchantmentId;
    
    // Remove "minecraft:" prefix
    size_t colonPos = name.find(':');
    if (colonPos != std::string::npos) {
        name = name.substr(colonPos + 1);
    }
    
    // Replace underscores with spaces
    for (char& c : name) {
        if (c == '_') c = ' ';
    }
    
    // Capitalize first letter of each word
    bool capitalizeNext = true;
    for (char& c : name) {
        if (capitalizeNext && std::isalpha(c)) {
            c = std::toupper(c);
            capitalizeNext = false;
        } else if (c == ' ') {
            capitalizeNext = true;
        }
    }
    
    return name;
}

// Get short display name (for compact HUD)
inline std::string getShortName(const std::string& enchantmentId) {
    std::string fullName = getDisplayName(enchantmentId);
    
    // Common abbreviations
    static const std::unordered_map<std::string, std::string> SHORT_NAMES = {
        {"Protection", "Prot"},
        {"Fire Protection", "Fire Prot"},
        {"Blast Protection", "Blast Prot"},
        {"Projectile Protection", "Proj Prot"},
        {"Feather Falling", "Feather Fall"},
        {"Bane of Arthropods", "Bane"},
        {"Sharpness", "Sharp"},
        {"Efficiency", "Eff"},
        {"Unbreaking", "Unbr"},
        {"Luck of the Sea", "Luck"},
        {"Curse of Binding", "Binding"},
        {"Curse of Vanishing", "Vanishing"},
        {"Sweeping Edge", "Sweeping"},
        {"Quick Charge", "Quick Chg"},
    };
    
    auto it = SHORT_NAMES.find(fullName);
    if (it != SHORT_NAMES.end()) {
        return it->second;
    }
    
    return fullName;
}

// Format enchantment with level for display
inline std::string formatEnchantment(const std::string& enchantmentId, int level, bool useShortName = false) {
    std::string name = useShortName ? getShortName(enchantmentId) : getDisplayName(enchantmentId);
    
    // Roman numeral conversion for levels
    static const std::vector<std::string> ROMAN = {
        "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"
    };
    
    if (level >= 1 && level <= 10) {
        return name + " " + ROMAN[level];
    } else if (level > 10) {
        return name + " " + std::to_string(level);
    } else {
        return name;
    }
}

} // namespace EnchantmentNames
